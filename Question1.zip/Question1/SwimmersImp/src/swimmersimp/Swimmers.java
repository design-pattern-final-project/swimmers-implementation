
package swimmersimp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Time;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Swimmers implements Implementation,Cloneable{


       ArrayList<swimmersObject> customers = new ArrayList<>();
       ArrayList<swimmersObject> young = new ArrayList<>();
       ArrayList<swimmersObject> teenagers = new ArrayList<>();
       ArrayList<swimmersObject> adult = new ArrayList<>();
       ArrayList<swimmersObject> best = new ArrayList<>();
    swimmersObject customer ;
//    Sql sq = new Sql();
    Sql sq = Sql.getInstance();

     @Override
 public ArrayList<swimmersObject> getAllSwimmers()
{
     ResultSet rs;
 if(sq.Connect()){
  String s = "SELECT * FROM swimmerstable"; 
 rs= sq.select(s);
   swimmersObject sw;
 
  

         try {
             while(rs.next()){
                 int id = rs.getInt("id");
                 Time time_completed =rs.getTime("time_completed");
                 String sex = rs.getString("sex");
                 String name = rs.getString("name");
                 String season = rs.getString("season");
                 String age_group = rs.getString("age_group");
                 Date birth = rs.getDate("birth_date");
                 int age = rs.getInt("age");
                 double distance = rs.getDouble("distance");
                 customer = new swimmersObject(id,name,sex,distance,age_group,birth,season,time_completed,age);
                 customers.add(customer);
             }  } catch (SQLException ex) {
             Logger.getLogger(Swimmers.class.getName()).log(Level.SEVERE, null, ex);
         }

  // getting values from the array list and updating its age group  
   for(swimmersObject customer : customers){
//       System.out.println(customer.name);
       Date some = customer.getBirth_date();
       int age = Math.round(getAge(Calendar.getInstance().getTime(),some));
       System.out.println(age);
       int idNo = customer.id;
        String quer ="UPDATE swimmerstable SET age = "+age+" WHERE id = "+idNo+"";   
           int selec;
         selec = sq.query(quer);
       if(age>20&&age<=35){
//          System.out.println(idNo);
        String query ="UPDATE swimmerstable SET age_group = 'young' WHERE id = "+idNo+"";   
         int sele;
         sele = sq.query(query);
       }
      else if(age<=20){
         String query ="UPDATE swimmerstable SET age_group = 'teenagers' WHERE id = "+idNo+"";   
       int sele;
         sele = sq.query(query);
       }
     else  if(age>=35){
        String query ="UPDATE swimmerstable SET age_group = 'adult' WHERE id = "+idNo+"";   
        int sele;
         sele = sq.query(query);
       
       }
  if (customer.getAge_group().equals("young")) {
      young.add(customer);
       }
    if (customer.getAge_group().equals("teenagers")) {
      teenagers.add(customer);
       }
    if(customer.getAge_group().equals("adult")){
      adult.add(customer);
    }
   } 

 


 
   
}
  return customers;
}
  @Override
public ArrayList<swimmersObject> best(){
      double m = 0;
      double m1 =0;
      double m2 =0;
      double m3 =0;
      double t = 0;
      double t1 =0;
      double t2 =0;
      double t3 =0;
      double a = 0;
      double a1 =0;
      double a2 =0;
      double a3 =0;
      swimmersObject sw = null;
      swimmersObject nd =null;
      swimmersObject td =null;
       swimmersObject fd =null;
      swimmersObject oF =null;
      swimmersObject oS =null;
      swimmersObject oT = null;
       swimmersObject Fs =null;
      swimmersObject aF =null;
      swimmersObject aS =null;
      swimmersObject aT = null;
       swimmersObject Ft =null;

   // this all is for young   

      
      for (swimmersObject swimmer: young) {
      if (swimmer.getSeason().equals("first")) {
              if (swimmer.getDistance() > m) {
                  m = swimmer.getDistance();
                   sw = swimmer;
                   
              }
              
          }
      }
      best.add(sw);
   for (swimmersObject swimmer: young) {
      if (swimmer.getSeason().equals("second")) {
              if (swimmer.getDistance() > m1) {
                  m1 = swimmer.getDistance();
                  nd= swimmer;
                 
              }
              
          }
      }
   best.add(nd);
  for (swimmersObject swimmer: young) {
      if (swimmer.getSeason().equals("third")) {
              if (swimmer.getDistance() > m2) {
                  m2 = swimmer.getDistance();
                  td= swimmer;
              
              }
              
          }
      }
  best.add(td);
    for (swimmersObject swimmer: young) {
      if (swimmer.getSeason().equals("fourth")) {
              if (swimmer.getDistance() > m3) {
                  m3 = swimmer.getDistance();
                  fd= swimmer;
              
              }
              
          }
      }
  best.add(fd);
//this is all is for teenagers

    
      for (swimmersObject swimmer: teenagers) {
      if (swimmer.getSeason().equals("first")) {
              if (swimmer.getDistance() > t) {
                  t = swimmer.getDistance();
                   oF = swimmer;
                   
              }
              
          }
      }
      best.add(oF);
   for (swimmersObject swimmer: teenagers) {
      if (swimmer.getSeason().equals("second")) {
              if (swimmer.getDistance() > t1) {
                  t1 = swimmer.getDistance();
                  oS= swimmer;
                 
              }
              
          }
      }
   best.add(oS);
  for (swimmersObject swimmer: teenagers) {
      if (swimmer.getSeason().equals("third")) {
              if (swimmer.getDistance() > t2) {
                  t2 = swimmer.getDistance();
                  oT= swimmer;
              
              }
              
          }
      }
  best.add(oT);
      for (swimmersObject swimmer: teenagers) {
      if (swimmer.getSeason().equals("fourth")) {
              if (swimmer.getDistance() > t3) {
                  t3 = swimmer.getDistance();
                  Fs= swimmer;
              
              }
              
          }
      }
  best.add(Fs);
  //this is all for adult
       for (swimmersObject swimmer: adult) {
      if (swimmer.getSeason().equals("first")) {
              if (swimmer.getDistance() > a) {
                  a= swimmer.getDistance();
                   aF = swimmer;
                   
              }
              
          }
      }
      best.add(aF);
   for (swimmersObject swimmer: adult) {
      if (swimmer.getSeason().equals("second")) {
              if (swimmer.getDistance() > a1) {
                  a1 = swimmer.getDistance();
                  aS= swimmer;
                 
              }
              
          }
      }
   best.add(aS);
  for (swimmersObject swimmer: adult) {
      if (swimmer.getSeason().equals("third")) {
              if (swimmer.getDistance() > a2) {
                  a2 = swimmer.getDistance();
                  aT= swimmer;
              
              }
              
          }
      }
  best.add(aT);
     for (swimmersObject swimmer: adult) {
      if (swimmer.getSeason().equals("fourth")) {
              if (swimmer.getDistance() > a3) {
                  a3 = swimmer.getDistance();
                  Ft= swimmer;
                 
              }
              
          }
      }
   best.add(Ft);


return best;


}


public static float getAge(final Date current, final Date birthdate) {

    if (birthdate == null) {
      return 0;
    }
 else {
      final Calendar calend = new GregorianCalendar();
      calend.set(Calendar.HOUR_OF_DAY, 0);
      calend.set(Calendar.MINUTE, 0);
      calend.set(Calendar.SECOND, 0);
      calend.set(Calendar.MILLISECOND, 0);

      calend.setTimeInMillis(current.getTime() - birthdate.getTime());

      float result = 0;
      result = calend.get(Calendar.YEAR) - 1970;
      result += (float) calend.get(Calendar.MONTH) / (float) 12;
//      int a = Math.round(result);
      return result;
    }

  }
   public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}       
}