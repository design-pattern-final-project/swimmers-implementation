/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package swimmersimp;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Kale
 */
public class SortedSex implements Implementation{
  Swimmers tw = new Swimmers();
  
       ArrayList<swimmersObject> sortedBS = new ArrayList<>();
         ArrayList<swimmersObject> sortedBBS = new ArrayList<>();

    @Override
 
    public ArrayList<swimmersObject> getAllSwimmers() {
        for(swimmersObject sd : tw.getAllSwimmers()){
            sortedBS.add(sd);
        }
         sortedBS.sort(new Comparator() {
          @Override
          public int compare(Object o1, Object o2) {
           swimmersObject   s1 = (swimmersObject) o1;
             swimmersObject s2 = (swimmersObject) o2;
              return s1.getSex().compareTo(s2.getSex());
          }
      });
     System.out.println("--------------------------------------------");
           System.out.println("*********The sorted Result By sex is******");
       for(swimmersObject customer : sortedBS){ 
             System.out.println(customer);
          
    }
   return sortedBS;

    }

       @Override
    public ArrayList<swimmersObject> best() {
 for(swimmersObject sd : tw.best()){
            sortedBBS.add(sd);
        }
         sortedBBS.sort(new Comparator() {
          @Override
          public int compare(Object o1, Object o2) {
           swimmersObject   s1 = (swimmersObject) o1;
             swimmersObject s2 = (swimmersObject) o2;
              return s1.getSex().compareTo(s2.getSex());
          }
      });
     System.out.println("--------------------------------------------");
           System.out.println("*********The sorted Result By sex is******");

   return sortedBBS;

    }

    
}
