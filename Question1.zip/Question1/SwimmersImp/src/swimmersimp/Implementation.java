
package swimmersimp;

import java.util.ArrayList;

public interface Implementation extends Cloneable {
  public ArrayList<swimmersObject>best();
  public  ArrayList<swimmersObject> getAllSwimmers();
//  public  ArrayList<swimmersObject> sortByTime();
//  public  ArrayList<swimmersObject> sortBySex();
}


