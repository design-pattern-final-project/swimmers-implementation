/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package swimmersimp;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Kale
 */
public class SwimmersGui extends javax.swing.JFrame {


   Strategy context = new Strategy(new SortedSex());
   Strategy conte = new Strategy(new Swimmers());
   Strategy cont = new Strategy(new SortedByBirthDate());
   Strategy sortedTime = new Strategy(new SortedTime());
   public SwimmersGui() throws SQLException, CloneNotSupportedException {
    
        initComponents();
        showUpOrginal();
    
  
    }
    public void showBirth(){
        DefaultTableModel model =  (DefaultTableModel) jTable1.getModel();
         model.setRowCount(0);
//        model.setNumRows(0);
        ArrayList<swimmersObject> Blist =   cont.executeStrategy(); 
        Object  rowData[] = new Object[7]; 
        for(int i = 0;i<Blist.size();i++){
            rowData[0] = Blist.get(i).name;
            rowData[1] = Blist.get(i).sex;
            rowData[2] = Blist.get(i).age;
            rowData[3] = Blist.get(i).age_group;
            rowData[4] = Blist.get(i).distance;
            rowData[5] = Blist.get(i).time_completed;
            rowData[6] = Blist.get(i).season;
            model.addRow(rowData);
            
        
    }
    }
    public void showBest(){
            DefaultTableModel model =  (DefaultTableModel) jTable1.getModel();
        model.setRowCount(0);
        ArrayList<swimmersObject> slist =   conte.executeBest();
        Object  rowData[] = new Object[7]; 
        for(int i = 0;i<slist.size();i++){
           rowData[0] = slist.get(i).name;
            rowData[1] = slist.get(i).sex;
            rowData[2] = slist.get(i).age;
            rowData[3] = slist.get(i).age_group;
            rowData[4] = slist.get(i).distance;
            rowData[5] = slist.get(i).time_completed;
            rowData[6] = slist.get(i).season;
            model.addRow(rowData);
    }
      
    }
    public void ShowTime(){
             DefaultTableModel model =  (DefaultTableModel) jTable1.getModel();
        model.setRowCount(0);
        ArrayList<swimmersObject> Tlist =   sortedTime.executeStrategy(); 
        Object  rowData[] = new Object[7]; 
        for(int i = 0;i<Tlist.size();i++){
          rowData[0] = Tlist.get(i).name;
            rowData[1] = Tlist.get(i).sex;
            rowData[2] = Tlist.get(i).age;
            rowData[3] = Tlist.get(i).age_group;
            rowData[4] = Tlist.get(i).distance;
            rowData[5] = Tlist.get(i).time_completed;
            rowData[6] = Tlist.get(i).season;
            model.addRow(rowData);
        }
    }
    public void showUpSorted() throws SQLException, CloneNotSupportedException{
//                 

 
              
        DefaultTableModel model =  (DefaultTableModel) jTable1.getModel();
          model.setRowCount(0);
        ArrayList<swimmersObject> Slist =   context.executeStrategy(); 

        Object  rowData[] = new Object[7]; 
        for(int i = 0;i<Slist.size();i++){
         rowData[0] = Slist.get(i).name;
            rowData[1] = Slist.get(i).sex;
            rowData[2] = Slist.get(i).age;
            rowData[3] = Slist.get(i).age_group;
            rowData[4] = Slist.get(i).distance;
            rowData[5] = Slist.get(i).time_completed;
            rowData[6] = Slist.get(i).season;
            model.addRow(rowData);
            
        
    }
       
    
    }
    public void showBestSortedBT(){
             
        DefaultTableModel model =  (DefaultTableModel) jTable1.getModel();
          model.setRowCount(0);
        ArrayList<swimmersObject> Slist =   sortedTime.executeBest(); 

        Object  rowData[] = new Object[7]; 
        for(int i = 0;i<Slist.size();i++){
         rowData[0] = Slist.get(i).name;
            rowData[1] = Slist.get(i).sex;
            rowData[2] = Slist.get(i).age;
            rowData[3] = Slist.get(i).age_group;
            rowData[4] = Slist.get(i).distance;
            rowData[5] = Slist.get(i).time_completed;
            rowData[6] = Slist.get(i).season;
            model.addRow(rowData);
            
        
    }}
    public void showBestSortedBS(){
             
        DefaultTableModel model =  (DefaultTableModel) jTable1.getModel();
          model.setRowCount(0);
        ArrayList<swimmersObject> Slist =   context.executeBest(); 

        Object  rowData[] = new Object[7]; 
        for(int i = 0;i<Slist.size();i++){
         rowData[0] = Slist.get(i).name;
            rowData[1] = Slist.get(i).sex;
            rowData[2] = Slist.get(i).age;
            rowData[3] = Slist.get(i).age_group;
            rowData[4] = Slist.get(i).distance;
            rowData[5] = Slist.get(i).time_completed;
            rowData[6] = Slist.get(i).season;
            model.addRow(rowData);
            
        
    }}
    public void showBestSortedBD(){
             
        DefaultTableModel model =  (DefaultTableModel) jTable1.getModel();
        ArrayList<swimmersObject> Slist =   cont.executeBest(); 

        Object  rowData[] = new Object[7]; 
        for(int i = 0;i<Slist.size();i++){
         rowData[0] = Slist.get(i).name;
            rowData[1] = Slist.get(i).sex;
            rowData[2] = Slist.get(i).age;
            rowData[3] = Slist.get(i).age_group;
            rowData[4] = Slist.get(i).distance;
            rowData[5] = Slist.get(i).time_completed;
            rowData[6] = Slist.get(i).season;
            model.addRow(rowData);
            
        
    }
    }
    public void showUpOrginal() throws CloneNotSupportedException, SQLException{


//        sw.getAllCustomers();
     DefaultTableModel mode =  (DefaultTableModel) jTable2.getModel();
        ArrayList<swimmersObject> list = conte.executeStrategy(); 
        Object  roData[] = new Object[7]; 
        for(int i = 0;i<list.size();i++){
            roData[0] = list.get(i).name;
            roData[1] = list.get(i).sex;
            roData[2] = list.get(i).age;
             roData[3] = list.get(i).age_group;
              roData[4] = list.get(i).distance;
             roData[5] = list.get(i).time_completed;
              roData[6] = list.get(i).season;
            mode.addRow(roData);
        
    }
    
    }
//            public void ShowTableOrginal(){
//        DefaultTableModel model =  (DefaultTableModel) jTable2.getModel();
//        ArrayList<swimmersObject> slist = sw.customers; 
//        Object  rowData[] = new Object[6]; 
//        for(int i = 0;i<slist.size();i++){
//            rowData[0] = slist.get(i).name;
//            rowData[1] = slist.get(i).sex;
//            rowData[2] = slist.get(i).age_group;
//             rowData[3] = slist.get(i).season;
//              rowData[4] = slist.get(i).time_completed;
//            model.addRow(rowData);
//    
//    }
//            }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        button2 = new java.awt.Button();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        button1 = new java.awt.Button();
        button3 = new java.awt.Button();
        button4 = new java.awt.Button();
        button5 = new java.awt.Button();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(0, 0, 0));

        jPanel1.setBackground(new java.awt.Color(0, 102, 102));

        button2.setBackground(new java.awt.Color(0, 0, 0));
        button2.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        button2.setForeground(new java.awt.Color(204, 204, 204));
        button2.setLabel("Exit");
        button2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button2ActionPerformed(evt);
            }
        });

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Name", "Sex", "Birth", "AgeGroup", "rank", "Time", "Season"
            }
        ));
        jTable1.setGridColor(new java.awt.Color(0, 51, 51));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jTable1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jTable1KeyPressed(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Name", "Sex", "Birth", "AgeGroup", "Time", "rank", "Season"
            }
        ));
        jScrollPane2.setViewportView(jTable2);

        button1.setBackground(new java.awt.Color(0, 0, 0));
        button1.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        button1.setForeground(new java.awt.Color(255, 255, 204));
        button1.setLabel("Best Swimmers");
        button1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button1ActionPerformed(evt);
            }
        });

        button3.setBackground(new java.awt.Color(0, 0, 0));
        button3.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        button3.setForeground(new java.awt.Color(255, 255, 255));
        button3.setLabel("Sorted By Time");
        button3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button3ActionPerformed(evt);
            }
        });

        button4.setBackground(new java.awt.Color(0, 0, 0));
        button4.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        button4.setForeground(new java.awt.Color(255, 255, 255));
        button4.setLabel("Sorted By Age");
        button4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button4ActionPerformed(evt);
            }
        });

        button5.setBackground(new java.awt.Color(0, 0, 0));
        button5.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        button5.setForeground(new java.awt.Color(255, 255, 255));
        button5.setLabel("Sorted By Sex");
        button5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button5ActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel1.setText("List Of All Swimmers");

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel2.setText("List Of Best Swimmers");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(238, 238, 238)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 219, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(321, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2)
                .addContainerGap(81, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(479, 479, 479)
                        .addComponent(button2, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 424, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(button5, javax.swing.GroupLayout.PREFERRED_SIZE, 213, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(button1, javax.swing.GroupLayout.PREFERRED_SIZE, 213, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(button3, javax.swing.GroupLayout.PREFERRED_SIZE, 213, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(button4, javax.swing.GroupLayout.PREFERRED_SIZE, 213, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(24, 24, 24)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 491, Short.MAX_VALUE)))
                .addContainerGap())
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(172, 172, 172)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 399, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED))
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                            .addGap(18, 18, 18)
                            .addComponent(button1, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(39, 39, 39)
                            .addComponent(button5, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(37, 37, 37)
                            .addComponent(button3, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(40, 40, 40)
                            .addComponent(button4, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED))
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 391, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(24, 24, 24))))
                .addComponent(button2, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void button2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button2ActionPerformed
        onStartUp fv = new onStartUp();
        fv.setVisible(true);
        this.dispose();
      
    }//GEN-LAST:event_button2ActionPerformed

    private void button5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button5ActionPerformed
     
       try {
           showUpSorted();
       } catch (SQLException ex) {
           Logger.getLogger(SwimmersGui.class.getName()).log(Level.SEVERE, null, ex);
       } catch (CloneNotSupportedException ex) {
           Logger.getLogger(SwimmersGui.class.getName()).log(Level.SEVERE, null, ex);
       }
    }//GEN-LAST:event_button5ActionPerformed

    private void button1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button1ActionPerformed
        // TODO add your handling code here:
          showBest();
    }//GEN-LAST:event_button1ActionPerformed

    private void button3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button3ActionPerformed
        ShowTime();
    }//GEN-LAST:event_button3ActionPerformed

    private void button4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button4ActionPerformed
         showBirth();
    }//GEN-LAST:event_button4ActionPerformed

    private void jTable1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable1KeyPressed
     
    }//GEN-LAST:event_jTable1KeyPressed

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
          
    }//GEN-LAST:event_jTable1MouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(SwimmersGui.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(SwimmersGui.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(SwimmersGui.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(SwimmersGui.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    new SwimmersGui().setVisible(true);
                } catch (SQLException ex) {
                    Logger.getLogger(SwimmersGui.class.getName()).log(Level.SEVERE, null, ex);
                } catch (CloneNotSupportedException ex) {
                    Logger.getLogger(SwimmersGui.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private java.awt.Button button1;
    private java.awt.Button button2;
    private java.awt.Button button3;
    private java.awt.Button button4;
    private java.awt.Button button5;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    // End of variables declaration//GEN-END:variables
}
