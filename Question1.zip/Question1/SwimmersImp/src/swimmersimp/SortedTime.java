/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package swimmersimp;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Kale
 */
public class SortedTime implements Implementation{
      Swimmers sw = new Swimmers();
      ArrayList<swimmersObject> sortedBT = new ArrayList<>();
        ArrayList<swimmersObject> sortedBBT = new ArrayList<>();

    @Override
 
    public ArrayList<swimmersObject> getAllSwimmers() {
        for(swimmersObject sd : sw.getAllSwimmers()){
            sortedBT.add(sd);
        }
         sortedBT.sort(new Comparator() {
          @Override
          public int compare(Object o1, Object o2) {
           swimmersObject   s1 = (swimmersObject) o1;
             swimmersObject s2 = (swimmersObject) o2;
              return s1.getTime_completed().compareTo(s2.getTime_completed());
          }
      });
     System.out.println("--------------------------------------------");
           System.out.println("*********The sorted Result By sex is******");

   return sortedBT;
    }
        @Override
    public ArrayList<swimmersObject> best() {
        for(swimmersObject sd : sw.best()){
            sortedBBT.add(sd);
        }
         sortedBBT.sort(new Comparator() {
          @Override
          public int compare(Object o1, Object o2) {
           swimmersObject   s1 = (swimmersObject) o1;
             swimmersObject s2 = (swimmersObject) o2;
              return s1.getTime_completed().compareTo(s2.getTime_completed());
          }
      });
     System.out.println("--------------------------------------------");
           System.out.println("*********The sorted Result By sex is******");

   return sortedBBT;
    }

}
