
package swimmersimp;

import java.sql.Time;
import java.util.Date;


public class swimmersObject {
   public  int id;
   public  String name;
   public  double distance;  
   public String age_group;
   public Date birth_date;
   public String sex;
   public String season;
   public Time time_completed;
   int age;

    public swimmersObject(int id,String name,String sex, double distance,String age_group,Date birth_date,String season,Time time_completed,int age) {
        this.age = age; 
        this.name= name;
        this.id = id;
        this.distance = distance;
        this.age_group = age_group;
        this.birth_date = birth_date;
        this.sex=sex;
        this.season= season;
        this.time_completed = time_completed;
    }  

   public swimmersObject() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public Time getTime_completed() {
        return time_completed;
    }

    public void setTime_completed(Time time_completed) {
        this.time_completed = time_completed;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getSeason() {
        return season;
    }

    public void setSeason(String season) {
        this.season = season;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }



    public void setDistance(double distance) {
        this.distance = distance;
    }
        public void setAge_group(String age_group) {
        this.age_group = age_group;
    }
 public void setBirth_date(Date birth_date) {
        this.birth_date = birth_date;
    }
    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

   

    public double getDistance() {
        return distance;
    }

    public String getAge_group() {
        return age_group;
    }
    public Date getBirth_date() {
        return birth_date;
    }

    public String getSex() {
        return sex;
    }
    
    public String getAll(){
      return getName()+" "+getSex()+" "+getBirth_date() +" "+getAge_group()+" "+ getDistance() + " "+ getSeason() + " " +getTime_completed() ;
    }


}
