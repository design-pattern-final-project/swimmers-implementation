package swimmersimp;

import java.util.ArrayList;


public class Strategy {
 private Implementation strategy;
 public Strategy(Implementation strategy){
      this.strategy = strategy;
   }

   public ArrayList<swimmersObject> executeStrategy(){
      return strategy.getAllSwimmers();
   }
      public ArrayList<swimmersObject>executeBest(){    
         return strategy.best();
   }
    
}
