
package swimmersimp;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.logging.Level;
import java.util.logging.Logger;


public class SortedByBirthDate implements Implementation{
          Swimmers sw = new Swimmers();
       ArrayList<swimmersObject> sortedBBD = new ArrayList();
        ArrayList<swimmersObject> sortedBBBD = new ArrayList();
    @Override
 
    public ArrayList<swimmersObject> getAllSwimmers() {
        for(swimmersObject ds : sw.getAllSwimmers()){
            sortedBBD.add(ds);
            
        }
         sortedBBD.sort(new Comparator() {
          @Override
          public int compare(Object o1, Object o2) {
           swimmersObject   s1 = (swimmersObject) o1;
             swimmersObject s2 = (swimmersObject) o2;
              return s2.getBirth_date().compareTo(s1.getBirth_date());
          }
      });
   return sortedBBD;
    }
        @Override
    public ArrayList<swimmersObject> best() {
               for(swimmersObject ds : sw.best()){
            sortedBBBD.add(ds);
            
        }
         sortedBBBD.sort(new Comparator() {
          @Override
          public int compare(Object o1, Object o2) {
           swimmersObject   s1 = (swimmersObject) o1;
             swimmersObject s2 = (swimmersObject) o2;
              return s2.getBirth_date().compareTo(s1.getBirth_date());
          }
      });
   return sortedBBBD;
    }
}
